const express = require('express');
const app = express();
const path = require('path');
const exphbs = require('express-handlebars');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

mongoose.Promise = global.Promise;



mongoose.connect('mongodb://127.0.0.1:27017/cms', {useMongoClient:true}).then((db)=>{
    console.log("MONGO CONNECTED")
}).catch((err)=>{
    console.log("COULD NOT CONNECTED",err)
})

app.use(express.static(path.join(__dirname, 'public')));

// set View engine

app.engine('handlebars', exphbs({ defaultLayout: 'home' }));
app.set("view engine", "handlebars");

// Body Parser 

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

// Laod Routes

const home = require("./routes/home/index")
const admin = require("./routes/admin/index")
const posts = require("./routes/admin/posts")


// use Routes

app.use("/", home);
app.use("/admin", admin);
app.use("/admin/posts", posts);



app.listen(4444, () => {
    console.log("listening on port 4444")
})